﻿window.__JGO_SCRIPTS__ = window.__JGO_SCRIPTS__ || {};
window.__JGO_SCRIPTS__['jogofuncoes.js'] = true;

let dinheiro = 1000;
let level = 1;
let xp = 0;
let xpRequired = 100;
let investimentoAtivo = false;
let funcionarios = 0;
let clientesInterval = null;
const impostoIntervaloMs = 3 * 60 * 1000; // 3 minutos
let impostoDeadline = null;
let impostoTimerId = null;
let impostoAtivo = true;

let tempoBaseClientes = 20000; // 20 segundos
let reducaoPorFuncionario = 3000; // 3s a menos por funcionário
let clientesAtendidos = 0;
let clientesPendentes = [];
let clienteCounter = 0;

let currentUser = localStorage.getItem('currentUser') || 'default';

let loginsSalvos = JSON.parse(localStorage.getItem('logins')) || [];
let userdata = loginsSalvos.find(l => l.nome === currentUser)

let bankName = userdata ? userdata.banco : 'default'
console.log("Usuário atual:", currentUser);
console.log("Banco atual:", bankName);

let currentZIndex = 1000;
let investimentoInterval = null;

// ===== Z-INDEX =====
function getNextZIndex() {
  return ++currentZIndex;
}

// ===== DRAG =====
function makeDraggable(element, handle) {
  if (!element || !handle) return;
  let isDragging = false;
  let offsetX, offsetY;

  handle.addEventListener('mousedown', (e) => {
    isDragging = true;
    offsetX = e.clientX - element.offsetLeft;
    offsetY = e.clientY - element.offsetTop;
    element.style.zIndex = getNextZIndex();
    document.body.style.userSelect = 'none';
  });

  document.addEventListener('mousemove', (e) => {
    if (isDragging) {
      element.style.left = (e.clientX - offsetX) + 'px';
      element.style.top = (e.clientY - offsetY) + 'px';
    }
  });

  document.addEventListener('mouseup', () => {
    isDragging = false;
    document.body.style.userSelect = '';
  });
}

// ===== GUI (SUBSTITUI ALERT / CONFIRM) =====
function guiAlert(message) {
  return new Promise(resolve => {
    const overlay = document.getElementById('guiOverlay');
    const msg = document.getElementById('alerta');
    const ok = document.getElementById('guiOk');

    msg.textContent = message;
    overlay.classList.remove('hidden');
    ok.classList.remove('hidden');

    ok.onclick = () => {
      overlay.classList.add('hidden');
      ok.classList.add('hidden');
      resolve(true);
    };
  });
}

function guiConfirm(message) {
  return new Promise(resolve => {
    const overlay = document.getElementById('guiOverlay');
    const msg = document.getElementById('alerta');
    const ok = document.getElementById('guiOk');
    const cancel = document.getElementById('guiCancel');

    msg.textContent = message;
    overlay.classList.remove('hidden');
    ok.classList.remove('hidden');
    cancel.classList.remove('hidden');

    ok.onclick = () => {
      overlay.classList.add('hidden');
      ok.classList.add('hidden');
      cancel.classList.add('hidden');
      resolve(true);
    };

    cancel.onclick = () => {
      overlay.classList.add('hidden');
      ok.classList.add('hidden');
      cancel.classList.add('hidden');
      resolve(false);
    };
  });
}

function isGamePage() {
  return !!(document.getElementById('dinheiro') || document.getElementById('clientesWindow'));
}

// ===== SAVE / LOAD =====
function salvarEstado() {
  const p = `${currentUser}_`;
  localStorage.setItem(p + 'dinheiro', dinheiro);
  localStorage.setItem(p + 'level', level);
  localStorage.setItem(p + 'xp', xp);
  localStorage.setItem(p + 'xpRequired', xpRequired);
  localStorage.setItem(p + 'clientesAtendidos', clientesAtendidos);
  localStorage.setItem(p + 'clientesPendentes', JSON.stringify(clientesPendentes));
  localStorage.setItem(p + 'clienteCounter', clienteCounter);
  localStorage.setItem(p + 'investimentoAtivo', investimentoAtivo);
  localStorage.setItem(p + 'funcionarios', funcionarios);
  localStorage.setItem(p + 'impostoAtivo', impostoAtivo);
}

function carregarEstado() {
  const p = `${currentUser}_`;
  dinheiro = parseInt(localStorage.getItem(p + 'dinheiro')) || 1000;
  level = parseInt(localStorage.getItem(p + 'level')) || 1;
  xp = parseInt(localStorage.getItem(p + 'xp')) || 0;
  xpRequired = parseInt(localStorage.getItem(p + 'xpRequired')) || 100;
  clientesAtendidos = parseInt(localStorage.getItem(p + 'clientesAtendidos')) || 0;
  clientesPendentes = JSON.parse(localStorage.getItem(p + 'clientesPendentes')) || [];
  clienteCounter = parseInt(localStorage.getItem(p + 'clienteCounter')) || 0;
  investimentoAtivo = localStorage.getItem(p + 'investimentoAtivo') === 'true';
  funcionarios = parseInt(localStorage.getItem(p + 'funcionarios')) || 0;
  const impostoSalvo = localStorage.getItem(p + 'impostoAtivo');
  impostoAtivo = impostoSalvo === null ? true : impostoSalvo === 'true';
}

// ===== HUD =====
const h3 = document.getElementById("dinheiro");
const h3Level = document.getElementById("level");
const h3Xp = document.getElementById("xp");
const h3Clientes = document.getElementById("atendidos");
const h3Funcionarios = document.getElementById("funcionarios");
const h3Temporizador = document.getElementById("temporizador");

function animarElemento(elemento, classe) {
  if (!elemento) return;
  elemento.classList.remove(classe);
  // Reinicia a animação quando chamada em sequência
  void elemento.offsetWidth;
  elemento.classList.add(classe);
  elemento.addEventListener('animationend', () => {
    elemento.classList.remove(classe);
  }, { once: true });
}

function atualizarDinheiro() {
  if (!h3) return;
  h3.textContent = `Dinheiro: R$ ${dinheiro}`;
}

function formatarTempo(ms) {
  const totalSegundos = Math.max(0, Math.ceil(ms / 1000));
  const minutos = Math.floor(totalSegundos / 60);
  const segundos = totalSegundos % 60;
  const s = String(segundos).padStart(2, '0');
  return `${minutos}:${s}`;
}

function atualizarTemporizador(ms) {
  if (!h3Temporizador) return;
  h3Temporizador.textContent = `imposto em: ${formatarTempo(ms)}`;
}

function atualizarFuncionarios() {
  if (!h3Funcionarios) return;
  h3Funcionarios.textContent = `Funcionários: ${funcionarios}`;
}
function atualizarClientes() {
  if (!h3Clientes) return;
  h3Clientes.textContent = `Clientes Atendidos: ${clientesAtendidos}`;
}

function atualizarLevel() {
  if (!h3Level) return;
  h3Level.textContent = `Level: ${level}`;
}

function atualizarXp() {
  if (!h3Xp) return;
  h3Xp.textContent = `XP: ${xp}/${xpRequired}`;
}

// ===== DINHEIRO =====
function adicionarDinheiro(valor) {
  dinheiro = Math.max(0, dinheiro + valor);
  atualizarDinheiro();
  if (valor > 0) animarElemento(h3, 'dinheiro-ganho');
  if (valor < 0) animarElemento(h3, 'dinheiro-perda');
  salvarEstado();
}

function perdeDinheiro(valor) {
  dinheiro = Math.max(0, dinheiro - valor);
  atualizarDinheiro();
  if (valor > 0) animarElemento(h3, 'dinheiro-perda');
  salvarEstado();
}

// ===== XP =====
function adicionarXp(valor) {
  xp += valor;

  if (valor > 0) animarElemento(h3Xp, 'level-ganho');
  if (valor < 0) animarElemento(h3Xp, 'level-perda');

  while (xp >= xpRequired) {
    xp -= xpRequired;
    level++;
    xpRequired = level * 100;
    atualizarLevel();
    animarElemento(h3Level, 'level-ganho');
  }

  atualizarXp();
  salvarEstado();
}

// ===== CLIENTES =====
function adicionarClientes(valor) {
  clientesAtendidos += valor;
  atualizarClientes();
  if (valor > 0) animarElemento(h3Clientes, 'cliente-ganho');
  if (valor < 0) animarElemento(h3Clientes, 'cliente-perda');
  salvarEstado();
}

// ===== JANELAS =====
function abrirchat() {
  const w = document.getElementById('clientesWindow');
  w.style.display = 'flex';
  w.style.zIndex = getNextZIndex();
}

function abrirCaixa() {
  const w = document.getElementById('caixaWindow');
  w.style.display = 'flex';
  w.style.zIndex = getNextZIndex();
}

function fecharCaixa() {
  document.getElementById('caixaWindow').style.display = 'none';
}

function fecharClientes() {
  document.getElementById('clientesWindow').style.display = 'none';
}

function abrirLoja() {
  const w = document.getElementById('lojaWindow');
  w.style.display = 'flex';
  w.style.zIndex = getNextZIndex();
}

function fecharLoja() {
  document.getElementById('lojaWindow').style.display = 'none';
}

function abrirBanco() {
  const w = document.getElementById('bancoWindow');
  if (!w) return;
  w.style.display = 'flex';
  w.style.zIndex = getNextZIndex();

  // Atualizar informações do banco
  const bancoList = document.getElementById('bancoList');
  if (!bancoList) return;
  bancoList.innerHTML = `
    <h4>Banco Atual: ${bankName}</h4>
    <p>Usuário: ${currentUser}</p>
    <p>Dinheiro em Conta: R$ ${dinheiro}</p>
  `;
}
function fecharbanco() {
  document.getElementById('bancoWindow').style.display = 'none';
}

function abrirTerminal() {
  const w = document.getElementById('terminalWindow');
  w.style.display = 'flex';
  w.style.zIndex = getNextZIndex();
  const input = document.getElementById('terminalInput');
  if (input) input.focus();
}

function fecharTerminal() {
  document.getElementById('terminalWindow').style.display = 'none';
}


// ===== CONTRATAR =====
async function contratar() {
  if (funcionarios >= 3) {
    await guiAlert('Você já contratou o número máximo de funcionários (3).');
    return;
  }

  if (dinheiro >= 1000 && level >= 4) {
    perdeDinheiro(1000);
    funcionarios++;
    salvarEstado();
    iniciarTimerClientes();
    atualizarFuncionarios();
    animarElemento(h3Funcionarios, 'funcionario-ganho');
    await guiAlert(`Funcionário contratado! Você agora tem ${funcionarios} funcionário(s).`);
  } else {
    await guiAlert('Você não tem dinheiro suficiente ou nível necessário.');
  }

}


// ===== INVESTIMENTO =====
function iniciarInvestimento() {
  if (investimentoInterval) return;
  investimentoInterval = setInterval(() => {
    adicionarDinheiro(50);
  }, 10000);
}

async function investimento() {
  if (investimentoAtivo) {
    await guiAlert('Você já possui um investimento ativo.');
    return;
  }

  if (dinheiro >= 500 && level >= 2) {
    perdeDinheiro(500);
    investimentoAtivo = true;
    salvarEstado();
    iniciarInvestimento();
    await guiAlert('Investimento realizado! Você ganhará R$ 50 a cada 10 segundos.');
  } else {
    await guiAlert('Você não tem dinheiro suficiente ou nível necessário.');
  }
}

// ===== CLIENTES TIMER =====
function iniciarTimerClientes() {
  if (clientesInterval) {
    clearInterval(clientesInterval);
  }

  clientesInterval = setInterval(() => {
    clienteCounter++;

    clientesPendentes.push({
      id: clienteCounter,
      nome: `Cliente ${clienteCounter}`
    });

    atualizarListaClientes();
    salvarEstado();
  }, calcularTempoCliente());
}


function calcularTempoCliente() {
  const tempo = tempoBaseClientes - (funcionarios * reducaoPorFuncionario);
  return Math.max(5000, tempo);
}

// ===== IMPOSTO TIMER =====
function aplicarImposto() {
  const impostoValor = 1000;
  perdeDinheiro(impostoValor);
  guiAlert(`Imposto cobrado: R$ ${impostoValor}`);
}


function iniciarTimerImposto() {
  if (!h3Temporizador) return;
  if (!impostoAtivo) {
    if (impostoTimerId) clearInterval(impostoTimerId);
    h3Temporizador.textContent = 'imposto desativado';
    return;
  }

  const p = `${currentUser}_`;
  const salvo = parseInt(localStorage.getItem(p + 'impostoDeadline'));
  const agora = Date.now();

  if (Number.isFinite(salvo) && salvo > agora) {
    impostoDeadline = salvo;
  } else {
    impostoDeadline = agora + impostoIntervaloMs;
  }

  localStorage.setItem(p + 'impostoDeadline', impostoDeadline);

  if (impostoTimerId) clearInterval(impostoTimerId);

  atualizarTemporizador(impostoDeadline - Date.now());

  impostoTimerId = setInterval(() => {
    const now = Date.now();
    let restante = impostoDeadline - now;

    if (restante <= 0) {
      aplicarImposto();
      impostoDeadline = now + impostoIntervaloMs;
      localStorage.setItem(p + 'impostoDeadline', impostoDeadline);
      restante = impostoDeadline - now;
    }

    atualizarTemporizador(restante);
  }, 1000);
}

function setImpostoAtivo(ativo) {
  impostoAtivo = ativo;
  salvarEstado();
  if (impostoAtivo) {
    iniciarTimerImposto();
  } else {
    if (impostoTimerId) clearInterval(impostoTimerId);
    if (h3Temporizador) {
      h3Temporizador.textContent = 'imposto desativado';
    }
  }
}


// ===== LISTA CLIENTES =====
function atualizarListaClientes() {
  const clientesList = document.getElementById('clientesList');
  if (!clientesList) return;
  clientesList.innerHTML = '';

  clientesPendentes.forEach(cliente => {
    const div = document.createElement('div');
    div.className = 'cliente-item';
    div.innerHTML = `<strong>${cliente.nome}</strong><br>ID: ${cliente.id}`;
    clientesList.appendChild(div);
  });
}

// ===== ABRIR CONTA =====
async function abrirConta() {
  if (clientesPendentes.length === 0) {
    await guiAlert('Nenhum cliente pendente!');
    return;
  }

  clientesPendentes.shift();
  adicionarClientes(1);
  adicionarDinheiro(100);
  adicionarXp(50);

  atualizarListaClientes();
  salvarEstado();
}

// ===== TERMINAL =====
function adicionarLinhaTerminal(texto) {
  const log = document.getElementById('terminalLog');
  if (!log) return;
  const div = document.createElement('div');
  div.className = 'linha';
  div.textContent = texto;
  log.appendChild(div);
  log.scrollTop = log.scrollHeight;
}

function executarComandoTerminal(comando) {
  const texto = comando.trim();
  if (!texto) return;

  const lower = texto.toLowerCase();

  if (lower === 'help' || lower === 'ajuda') {
    adicionarLinhaTerminal('Comandos disponíveis:');
    adicionarLinhaTerminal('- dinheiro = 1000 (adiciona dinheiro)');
    adicionarLinhaTerminal('- imposto = true | false (ativa/desativa imposto)');
    adicionarLinhaTerminal('- ativa imposto');
    adicionarLinhaTerminal('- desativa imposto');
    return;
  }

  let match = lower.match(/^dinheiro\s*=\s*(-?\d+)/);
  if (match) {
    const valor = parseInt(match[1], 10);
    adicionarDinheiro(valor);
    adicionarLinhaTerminal(`+ R$ ${valor} adicionados.`);
    return;
  }

  match = lower.match(/^imposto\s*=\s*(true|false)/);
  if (match) {
    const ativo = match[1] === 'true';
    setImpostoAtivo(ativo);
    adicionarLinhaTerminal(ativo ? 'Imposto ativado.' : 'Imposto desativado.');
    return;
  }

  if (lower === 'desativa imposto') {
    setImpostoAtivo(false);
    adicionarLinhaTerminal('Imposto desativado.');
    return;
  }

  if (lower === 'ativa imposto') {
    setImpostoAtivo(true);
    adicionarLinhaTerminal('Imposto ativado.');
    return;
  }

  adicionarLinhaTerminal('Comando não reconhecido.');
}

function enviarComandoTerminal() {
  const input = document.getElementById('terminalInput');
  if (!input) return;
  const texto = input.value;
  if (texto.trim() === '') return;
  adicionarLinhaTerminal(`> ${texto}`);
  executarComandoTerminal(texto);
  input.value = '';
}

// ===== INÍCIO =====
function iniciarJogo() {
  carregarEstado();
  if (investimentoAtivo) iniciarInvestimento();

  atualizarDinheiro();
  atualizarLevel();
  atualizarFuncionarios();
  atualizarXp();
  atualizarClientes();
  iniciarTimerClientes();
  iniciarTimerImposto();
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {

  if (!isGamePage()) return;

  iniciarJogo();

  makeDraggable(
    document.getElementById('clientesWindow'),
    document.querySelector('.clientes-header')
  );

  makeDraggable(
    document.getElementById('lojaWindow'),
    document.querySelector('.loja-header')
  );

  makeDraggable(
    document.getElementById('bancoWindow'),
    document.querySelector('.banco-header')
  );

  makeDraggable(
    document.getElementById('terminalWindow'),
    document.querySelector('.terminal-header')
  );

  makeDraggable(
    document.getElementById('caixaWindow'),
    document.querySelector('.caixa-header')
  );

  const terminalInput = document.getElementById('terminalInput');
  if (terminalInput) {
    terminalInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        enviarComandoTerminal();
      }
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.shiftKey && e.key === 'Enter') {
      e.preventDefault();
      abrirTerminal();
    }
  });
});


